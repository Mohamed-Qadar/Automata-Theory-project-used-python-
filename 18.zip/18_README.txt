Please follow the steps below to install the packages necessary to run this program.
Open the terminal window(on Pycharm, it is located on the left down conner of the window) and type the following one after
the other to install these packages;

1. pip install graphviz
2. pip install Pillow   (notice the letter P is capitalized)
3. pip install tk

After installing the above packages, head to https://graphviz.org/download/ and download and install the graphviz package 
manually according to your operating system. (for windows os, you can also simply use the link below)
https://gitlab.com/graphviz/graphviz/-/package_files/9574245/download 

After installing the graphviz package manually, copy the path where it has been installed on your system (computer)
and add it to both system path and user path. Please if you have any difficulty doing this, kindly leave an email
and I will help you out. (abdulaihalidu008@gmail.com).

After following the above instructions, the program should be running and working correctly.

Note: Kindly follow all instructions on each page of the GUI to ensure the smooth working of the program.